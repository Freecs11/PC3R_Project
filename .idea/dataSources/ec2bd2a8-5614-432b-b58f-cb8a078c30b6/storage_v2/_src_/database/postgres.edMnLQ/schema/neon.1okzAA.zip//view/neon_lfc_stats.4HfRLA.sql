create view neon_lfc_stats(lfc_key, lfc_value) as
SELECT lfc_key,
       lfc_value
FROM neon.neon_get_lfc_stats() p(lfc_key text, lfc_value bigint);

alter table neon_lfc_stats
    owner to cloud_admin;

